/**
 * TKBirthdayReminderInitOnly.java
 * 
 * TKBirthdayReminder (c) Thomas Künneth 2009
 * 
 * Alle Rechte beim Autoren. All rights reserved.
 */
package com.thomaskuenneth.android.birthday;

/**
 * Diese Klasse signalisiert, dass nach dem Setzen des Alarms nicht die GUI
 * angezeigt werden soll.
 * 
 * @author Thomas Künneth
 * 
 */
public class TKBirthdayReminderInitOnly extends TKBirthdayReminder {

}