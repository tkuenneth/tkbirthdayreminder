/**
 * BirthdaySetActivity.java
 * 
 * TKBirthdayReminder (c) Thomas Künneth 2009
 * 
 * Alle Rechte beim Autoren. All rights reserved.
 */
package com.thomaskuenneth.android.birthday;


public class BirthdaySetActivity extends AbstractListActivity {

	public BirthdaySetActivity() {
		super(ContactsList.getListBirthdaySet());
	}

}
