/**
 * ContactsList.java
 * 
 * TKBirthdayReminder (c) Thomas Künneth 2009
 * 
 * Alle Rechte beim Autoren. All rights reserved.
 */
package com.thomaskuenneth.android.birthday;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.Contacts;
import android.provider.Contacts.People;

public class ContactsList {

	/**
	 * Hält eine Liste aller Kontakte.
	 */
	private static final List<BirthdayItem> contacts = new ArrayList<BirthdayItem>();

	public static List<BirthdayItem> getContacts() {
		return contacts;
	}

	/**
	 * Liest alle Kontakte erneut aus der Datenbank.
	 */
	public static synchronized List<BirthdayItem> rereadContacts(Context context) {
		contacts.clear();
		ContentResolver contentResolver = context.getContentResolver();
		String[] projection = new String[] { People.DISPLAY_NAME, People.NOTES,
				People._ID, People.NUMBER };
		Uri uri = Uri.parse("content://contacts/groups/system_id/"
				+ Contacts.Groups.GROUP_MY_CONTACTS + "/members");
		// uri = Contacts.People.CONTENT_URI
		Cursor c = contentResolver.query(uri, projection, null, null, null);
		if (c != null) {
			for (;;) {
				if (c.moveToNext() == false) {
					break;
				}
				String name = c.getString(0);
				String notes = c.getString(1);
				long id = c.getLong(2);
				String primaryPhoneNumber = c.getString(3);
				BirthdayItem item = new BirthdayItem(name, DateUtils
						.getDateFromString(notes), id, primaryPhoneNumber);
				contacts.add(item);
			}
			c.close();
		}
		return contacts;
	}
}
